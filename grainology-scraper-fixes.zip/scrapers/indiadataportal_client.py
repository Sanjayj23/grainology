"""
IndiaDataPortal client — fetches agricultural price data from
ISB's IndiaDataPortal (indiadataportal.com).

STATUS: disabled by default in run_all.py as of this rewrite. Two things
were checked directly against IndiaDataPortal's actual CKAN catalog
(ckandev.indiadataportal.com) before deciding this:
  1. The endpoints this client calls (api/v1/datasets/..., api/v1/agri/...)
     don't exist on the real platform -- that's the literal cause of every
     "Expecting value: line 1 column 0" error in your original log (HTML
     404 pages parsed as JSON). The real platform is CKAN-based.
  2. More importantly: the CKAN "APMC arrivals and prices (Agmarknet)"
     resource that actually matches this use case has its datastore marked
     inactive (no queryable API table), and its last-updated date is
     December 2024 -- over a year stale. Even a fully correct integration
     would not give you "live" prices from this source right now.

Given that, this isn't worth presenting next to genuinely live sources in
a comparative dashboard -- stale data labeled as "live" is actively
misleading. The function below is left in place so the file still imports
cleanly, but it is no longer called from run_all.py's default pipeline.
Re-enable there if you specifically want an occasional historical-baseline
job, separate from the daily live comparison.
"""

from __future__ import annotations
import logging
import os
import time
from datetime import date, datetime, timezone
from typing import Optional

from playwright.sync_api import Page
from dateutil import parser as dateutil_parser

from schema import PriceRecord
from normalize import normalize_commodity, normalize_market

logger = logging.getLogger(__name__)

IDP_BASE_URL = "https://indiadataportal.com/api/v1"
AGRI_DATASET_ID = "agriculture-marketing"

def _get_idp_key() -> Optional[str]:
    return os.environ.get("IDP_API_KEY", "")


def fetch_indiadataportal(
    target_date: Optional[date] = None,
    page: Page = None,
    days_back: int = 7,
) -> list[PriceRecord]:
    """
    Fetch price data from IndiaDataPortal using Playwright to bypass WAFs.
    """
    if target_date is None:
        target_date = date.today()

    fetched_at = datetime.now(tz=timezone.utc)
    all_records: list[PriceRecord] = []
    api_key = _get_idp_key()

    logger.info("IndiaDataPortal: fetching data for last %d days ending %s", days_back, target_date)

    headers = {
        "Accept": "application/json",
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    endpoints = [
        f"{IDP_BASE_URL}/datasets/{AGRI_DATASET_ID}",
        f"{IDP_BASE_URL}/agri/mandi-prices",
        "https://indiadataportal.com/p/agriculture-marketing/api",
    ]

    try:
        page.goto("https://indiadataportal.com/p/agriculture-marketing", wait_until="domcontentloaded", timeout=30000)
        time.sleep(2)
    except Exception as exc:
        logger.warning("IDP: could not load homepage to get cookies: %s", exc)

    for endpoint in endpoints:
        try:
            params = {
                "limit": "5000",
                "format": "json",
            }
            
            query_str = "&".join([f"{k}={v}" for k, v in params.items()])
            full_url = f"{endpoint}?{query_str}"
            
            resp = page.request.get(full_url, headers=headers)
            
            if resp.status == 404:
                continue
                
            if not resp.ok:
                logger.warning("IDP: endpoint %s failed with HTTP %s", endpoint, resp.status)
                continue
                
            data = resp.json()

            raw_records = (
                data if isinstance(data, list) else
                data.get("data", []) or
                data.get("records", []) or
                []
            )

            logger.info("IndiaDataPortal: endpoint %s → %d raw records", endpoint, len(raw_records))

            for raw in raw_records:
                try:
                    raw_state     = raw.get("state", raw.get("State", ""))
                    raw_district  = raw.get("district", raw.get("District", ""))
                    raw_market    = raw.get("market", raw.get("Market", raw.get("mandi", "")))
                    raw_commodity = raw.get("commodity", raw.get("Commodity", ""))
                    raw_variety   = raw.get("variety", raw.get("Variety", ""))
                    min_p   = float(str(raw.get("min_price", raw.get("Min_Price", 0))).replace(",", "") or 0)
                    max_p   = float(str(raw.get("max_price", raw.get("Max_Price", 0))).replace(",", "") or 0)
                    modal_p = float(str(raw.get("modal_price", raw.get("Modal_Price", max_p))).replace(",", "") or 0)

                    date_str = raw.get("date", raw.get("arrival_date", raw.get("Date", "")))
                    try:
                        price_date = dateutil_parser.parse(date_str).date()
                    except Exception:
                        price_date = target_date

                    if not raw_commodity:
                        continue

                    commodity, _ = normalize_commodity(raw_commodity)
                    market, district, state, _ = normalize_market(raw_market, raw_district, raw_state)

                    record = PriceRecord(
                        source="indiadataportal",
                        fetched_at=fetched_at,
                        price_date=price_date,
                        state=state,
                        district=district,
                        market=market,
                        commodity=commodity,
                        variety=raw_variety.strip(),
                        min_price=max(min_p, 0.01),
                        max_price=max(max_p, 0.01),
                        modal_price=max(modal_p, 0.01),
                        arrivals_tonnes=None,
                        raw_source_name=raw_commodity,
                    )
                    all_records.append(record)
                except Exception as exc:
                    logger.debug("IDP: skipping row %r: %s", raw, exc)

            if all_records:
                break  # success

        except Exception as exc:
            logger.warning("IDP: endpoint %s failed: %s", endpoint, exc)

        time.sleep(0.5)

    if not all_records:
        logger.warning("IndiaDataPortal: no data retrieved.")

    logger.info("IndiaDataPortal: %d valid records", len(all_records))
    return all_records
